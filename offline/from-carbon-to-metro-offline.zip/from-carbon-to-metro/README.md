# 從碳客變捷客 (From Carbon to Metro)

> 2026 捷運盃黑客松「玩點生活・智慧串聯」創新應用競賽 — App Mockup

## 線上預覽

🔗 **[Live Demo](https://sofiayan0523.github.io/from-carbon-to-metro/)**

## 本地預覽

目前專案是純靜態 HTML/CSS/JavaScript。建議用本機靜態 server 預覽，確保本地字型與離線 QA 行為和 GitHub Pages 一致：

```bash
python3 -m http.server 4173 --bind 127.0.0.1
```

開啟 <http://127.0.0.1:4173/> 可看民眾投票展示頁；完整互動 prototype 在 <http://127.0.0.1:4173/demo/>。

如果現場電腦沒有 Python，也可以直接用瀏覽器開啟 `index.html` 作為展示頁 fallback；完整互動 demo 建議使用 static server 開啟 `demo/`。

## 決賽交付策略

線上投票展示採 Cloudflare Pages：根目錄是民眾版展示頁，同站內 `/demo/` 保留完整 prototype。離線備援包確保主辦單位電腦沒有網路時仍可完成 demo。細節見 [`docs/delivery-strategy.md`](docs/delivery-strategy.md)。

## 決賽提交包

- 線上投票展示頁：<https://from-carbon-metro-vote.pages.dev/>
- 線上互動 prototype：<https://from-carbon-metro-vote.pages.dev/demo/>
- 測試步驟：[`TESTING_STEPS.md`](TESTING_STEPS.md)
- 送件檢查清單：[`SUBMISSION_CHECKLIST.md`](SUBMISSION_CHECKLIST.md)
- 離線備援包：`offline/from-carbon-to-metro-offline.zip`
- 離線包說明：[`offline/README.md`](offline/README.md)

## 專案介紹

「從碳客變捷客」是整合於台北捷運 Go App 的通勤生活服務模組，結合**個人化點數導航**與**碳足跡回饋**雙引擎：

- **小捷點數路線引擎** — 根據用戶通勤動線推薦沿途賺點 / 用點商家與集章任務
- **碳足跡捷運點加成** — 以官方參考係數 `(104 - 75) = 29 gCO₂e/km` 換算碳節省量，並用 5 kg / 10 kg 門檻轉成捷運點乘數加成
- **今日捷運點互動** — 完成通勤、翻每日捷運點卡、累積點數與查看推薦站點
- **Numbers 可信證明** — 以 opt-in 隱私同意呈現去識別月度 proof record、資料指紋與可重播稽核軌跡

## 四大可導航區塊

1. **今天** — 通勤減碳摘要、捷運點餘額、每日捷運點卡與順路推薦
2. **路線** — 板南線站點情境、小捷商家推薦、站內補給站、分類篩選與捷運章任務
3. **減碳** — 日 / 月 / 年報告切換、額外通勤模擬、5 kg / 10 kg 捷運點加成門檻、減碳森林與 14 天趨勢
4. **我的** — 成就徽章牆、我的小隊、Numbers 可信證明、opt-in 控制、資料指紋、稽核軌跡重播與分享卡

## 團隊：通勤族也想拯救地球

| 成員 | 任職單位 | 分工 |
|------|---------|------|
| 嚴世紀（隊長） | 主張數據股份有限公司 Numbers Protocol | 系統架構、路線推薦、碳數據可信度 |
| 鍾天傑 | 連加網絡商業股份有限公司 LINE Pay | 點數經濟、支付整合、UX |
| 嚴世裕 | 台北市政府地政局 | ESG 政策對接、政府資料整合 |

## 技術

純 HTML/CSS/JavaScript（無 build step、無外部 API 依賴），任何現代瀏覽器可開啟。根目錄 `index.html` 是民眾投票展示頁；新版 UI/UX prototype bundle 位於 `demo/index.html`，前端 runtime 固定版本放在 `demo/assets/vendor/`，字型資源與授權文件保留在 `assets/fonts/`，確保 Cloudflare Pages 與離線包都不需要 CDN。小捷路線推薦使用本機展示商家資料集，碳足跡以官方參考係數呈現：`小客車 104 gCO₂e/km - 捷運 75 gCO₂e/km = 差額 29 gCO₂e/km`；通勤完成、每日捷運點卡、健康共享生活圈、站內補給站、路線集章、成就徽章、趨勢圖、分享卡與可信證明都由同一組本機 demo state 驅動。Proof flow 只保留月份、減碳值、距離區間、任務類型與資料指紋，不保存完整起訖站、商家、精確時間或個人識別碼。正式產品將整合於台北捷運 Go App，串接正式碳排係數與捷運點數系統。
